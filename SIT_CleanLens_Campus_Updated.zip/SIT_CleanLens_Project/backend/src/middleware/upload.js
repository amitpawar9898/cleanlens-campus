const multer = require('multer'), path = require('path'), fs = require('fs'), crypto = require('crypto'), cfg = require('../config'), { HttpError } = require('../utils');
fs.mkdirSync(cfg.uploadDir, { recursive: true });
const ok = ['image/jpeg', 'image/png', 'image/webp'];
const filter = (req, f, cb) => ok.includes(f.mimetype) ? cb(null, true) : cb(new HttpError(400, 'Only JPG, PNG or WEBP images are allowed'));
const limits = { fileSize: 5 * 1024 * 1024, files: 5 };
const disk = multer({ limits, fileFilter: filter, storage: multer.diskStorage({
  destination: cfg.uploadDir,
  filename: (r, f, cb) => cb(null, crypto.randomBytes(12).toString('hex') + path.extname(f.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '')) }) });
const mem = multer({ limits, fileFilter: filter, storage: multer.memoryStorage() });
module.exports = { disk, mem, url: f => '/uploads/' + f.filename };
