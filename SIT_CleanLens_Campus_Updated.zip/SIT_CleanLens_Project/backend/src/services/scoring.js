const { q } = require('../db');
const W = { Low: 3, Medium: 6, High: 10, Critical: 15 };
const level = s => s >= 85 ? 'Good' : s >= 70 ? 'Needs Attention' : s >= 55 ? 'Poor' : 'Critical';
async function buildingScores() {
  const { rows } = await q(`SELECT b.id,b.name,b.lat,b.lng,
    COALESCE(json_agg(c.priority) FILTER (WHERE c.id IS NOT NULL),'[]') pri
    FROM buildings b LEFT JOIN complaints c ON c.building_id=b.id AND c.status NOT IN ('Resolved','Closed','Rejected') GROUP BY b.id ORDER BY b.name`);
  return rows.map(r => { const pen = r.pri.reduce((a, p) => a + (W[p] || 0), 0), score = Math.max(30, 100 - pen);
    return { id: r.id, name: r.name, lat: r.lat, lng: r.lng, open_complaints: r.pri.length, score, level: level(score) }; });
}
module.exports = { buildingScores, level };
