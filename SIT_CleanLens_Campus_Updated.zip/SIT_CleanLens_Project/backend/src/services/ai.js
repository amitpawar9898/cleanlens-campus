const cfg = require('../config'), { HttpError } = require('../utils');
const CATS = ['Cleaning', 'Maintenance', 'Waste', 'Pest', 'Other'], PRI = ['Low', 'Medium', 'High', 'Critical'];
async function call(images, text) {
  if (!cfg.anthropicKey) throw new HttpError(503, 'AI is not configured. Set ANTHROPIC_API_KEY on the server.');
  const content = [...images.map(i => ({ type: 'image', source: { type: 'base64', media_type: i.mime, data: i.buf.toString('base64') } })), { type: 'text', text }];
  const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': cfg.anthropicKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: cfg.model, max_tokens: 900, messages: [{ role: 'user', content }] }) });
  const j = await r.json();
  if (!r.ok) throw new HttpError(502, 'AI provider error: ' + ((j.error && j.error.message) || r.status));
  const t = j.content.filter(x => x.type === 'text').map(x => x.text).join('');
  try { return JSON.parse(t.replace(/```json|```/g, '').trim()); } catch { throw new HttpError(502, 'AI returned an unreadable answer'); }
}
const PROMPT = `You are a campus cleanliness and maintenance inspector for a university. Look only at what is visible in the photo (kitchens, canteens, washrooms, water leaks and waste, garbage, floors, taps, drains, walls and similar). Never comment on health or disease. Reply with ONLY JSON: {"relevant":true,"condition":"Good|Needs Improvement|Poor|Critical","confidence":0-100,"issues":[{"name":"short issue name","severity":"Low|Medium|High|Critical","confidence":0-100}],"category":"Cleaning|Maintenance|Waste|Pest|Other","priority":"Low|Medium|High|Critical","title":"max 6 words","description":"2 short sentences: what is visible and what should be done","building":"best match from the list or empty","floor":"best match or empty","spot":"best match or empty"}. Set relevant to false if the photo does not show a campus space or a cleanliness or maintenance issue. Only report issues you can actually see. Campus locations:\n`;
exports.analyze = async (buf, mime, spotsText) => {
  const o = await call([{ buf, mime }], PROMPT + spotsText);
  o.issues = Array.isArray(o.issues) ? o.issues : [];
  if (!CATS.includes(o.category)) o.category = 'Other';
  if (!PRI.includes(o.priority)) o.priority = 'Medium';
  o.relevant = o.relevant !== false; o.mode = 'Claude vision'; return o;
};
exports.compare = async (before, after) => {
  const o = await call([before, after], `Image 1 is BEFORE cleaning and image 2 is AFTER cleaning of the same campus area. Judge only visible cleanliness. Reply with ONLY JSON: {"before_score":0-100,"after_score":0-100,"notes":"one or two sentences"}.`);
  const c = n => Math.max(0, Math.min(100, Math.round(+n || 0)));
  return { before_score: c(o.before_score), after_score: c(o.after_score), improvement: c(o.after_score) - c(o.before_score), notes: String(o.notes || '') };
};
