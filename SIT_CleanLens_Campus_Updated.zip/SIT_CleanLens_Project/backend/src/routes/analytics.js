const router = require('express').Router(), { q } = require('../db'), { auth, role } = require('../middleware/auth'), { ah } = require('../utils'), { buildingScores, level } = require('../services/scoring');
router.use(auth, role('admin', 'staff'));
router.get('/summary', ah(async (req, res) => {
  const s = (await q(`SELECT count(*)::int total,count(*) FILTER (WHERE status IN ('Submitted','Open','Reviewed'))::int open,count(*) FILTER (WHERE status IN ('Assigned','In Progress','Pending Verification'))::int in_progress,
    count(*) FILTER (WHERE status IN ('Resolved','Closed'))::int resolved,
    round(avg(extract(epoch FROM resolved_at-created_at)/3600) FILTER (WHERE resolved_at IS NOT NULL)::numeric,1) avg_resolution_hours,
    round(avg(feedback_rating)::numeric,2) avg_rating FROM complaints`)).rows[0];
  const b = await buildingScores(), score = b.length ? Math.round(b.reduce((a, x) => a + x.score, 0) / b.length) : 100;
  res.json({ ...s, campus_score: score, campus_level: level(score), locations_requiring_attention: b.filter(x => x.score < 85).length, locations_monitored: b.length });
}));
router.get('/by-category', ah(async (req, res) => res.json((await q('SELECT category,count(*)::int count FROM complaints GROUP BY category ORDER BY count DESC')).rows)));
router.get('/by-priority', ah(async (req, res) => res.json((await q('SELECT priority,count(*)::int count FROM complaints GROUP BY priority ORDER BY count DESC')).rows)));
router.get('/timeseries', ah(async (req, res) => {
  const days = Math.min(Math.max(+req.query.days || 7, 1), 90);
  res.json((await q(`SELECT d::date AS day,(SELECT count(*)::int FROM complaints WHERE created_at::date=d::date) submitted,(SELECT count(*)::int FROM complaints WHERE resolved_at::date=d::date) resolved
    FROM generate_series(now()::date-($1::int-1),now()::date,'1 day') d ORDER BY d`, [days])).rows);
}));
router.get('/locations', ah(async (req, res) => res.json((await buildingScores()).sort((a, b) => b.score - a.score))));
router.get('/cleaners', ah(async (req, res) => res.json((await q(`SELECT u.id,u.name,count(t.*)::int tasks,count(t.*) FILTER (WHERE t.status='Completed')::int completed,
  round(avg(t.after_score-t.before_score) FILTER (WHERE t.after_score IS NOT NULL AND t.before_score IS NOT NULL)::numeric,1) avg_improvement
  FROM users u LEFT JOIN tasks t ON t.cleaner_id=u.id WHERE u.role='cleaner' GROUP BY u.id ORDER BY completed DESC`)).rows)));
module.exports = router;
