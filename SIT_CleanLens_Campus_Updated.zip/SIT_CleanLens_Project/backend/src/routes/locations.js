const router = require('express').Router(), { z } = require('zod');
const { q } = require('../db'), { auth, role } = require('../middleware/auth'), { ah, HttpError } = require('../utils'), { buildingScores } = require('../services/scoring');
router.use(auth);
router.get('/buildings', ah(async (req, res) => {
  const { rows } = await q(`SELECT b.*,COALESCE(json_agg(json_build_object('id',s.id,'floor',s.floor,'name',s.name) ORDER BY s.floor,s.name) FILTER (WHERE s.id IS NOT NULL),'[]') spots FROM buildings b LEFT JOIN spots s ON s.building_id=b.id GROUP BY b.id ORDER BY b.name`);
  res.json(rows);
}));
router.get('/map', ah(async (req, res) => res.json(await buildingScores())));
router.post('/buildings', role('admin'), ah(async (req, res) => {
  const b = z.object({ name: z.string().min(2), lat: z.number().optional(), lng: z.number().optional() }).parse(req.body);
  res.status(201).json((await q('INSERT INTO buildings(name,lat,lng) VALUES($1,$2,$3) RETURNING *', [b.name, b.lat ?? null, b.lng ?? null])).rows[0]);
}));
router.patch('/buildings/:id', role('admin'), ah(async (req, res) => {
  const b = z.object({ name: z.string().min(2).optional(), lat: z.number().optional(), lng: z.number().optional() }).parse(req.body);
  const r = (await q('UPDATE buildings SET name=COALESCE($1,name),lat=COALESCE($2,lat),lng=COALESCE($3,lng) WHERE id=$4 RETURNING *', [b.name, b.lat, b.lng, req.params.id])).rows[0];
  if (!r) throw new HttpError(404, 'Building not found'); res.json(r);
}));
router.delete('/buildings/:id', role('admin'), ah(async (req, res) => { await q('DELETE FROM buildings WHERE id=$1', [req.params.id]); res.json({ ok: true }); }));
router.post('/buildings/:id/spots', role('admin'), ah(async (req, res) => {
  const b = z.object({ floor: z.string().default('Ground Floor'), name: z.string().min(1) }).parse(req.body);
  res.status(201).json((await q('INSERT INTO spots(building_id,floor,name) VALUES($1,$2,$3) RETURNING *', [req.params.id, b.floor, b.name])).rows[0]);
}));
router.delete('/spots/:id', role('admin'), ah(async (req, res) => { await q('DELETE FROM spots WHERE id=$1', [req.params.id]); res.json({ ok: true }); }));
module.exports = router;
