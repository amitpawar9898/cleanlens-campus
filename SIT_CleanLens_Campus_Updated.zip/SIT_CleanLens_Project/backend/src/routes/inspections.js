const router = require('express').Router(), { q } = require('../db'), { auth, role } = require('../middleware/auth'), { disk, url } = require('../middleware/upload');
const { ah, HttpError, page } = require('../utils'), ai = require('../services/ai'), fs = require('fs'), path = require('path'), cfg = require('../config');
const { signed } = require('../services/files'), sg = r => ({ ...r, image_url: signed(r.image_url) });
router.use(auth, role('admin', 'staff', 'cleaner'));
router.post('/', disk.single('image'), ah(async (req, res) => {
  if (!req.file) throw new HttpError(400, 'image file is required (field name: image)');
  let out = null;
  if (cfg.anthropicKey) {
    const { rows } = await q('SELECT b.name b,s.floor f,s.name s FROM buildings b JOIN spots s ON s.building_id=b.id'), m = {};
    rows.forEach(r => { ((m[r.b] = m[r.b] || {})[r.f] = m[r.b][r.f] || []).push(r.s); });
    out = await ai.analyze(fs.readFileSync(path.join(cfg.uploadDir, req.file.filename)), req.file.mimetype, Object.entries(m).map(([b, f]) => b + ': ' + Object.entries(f).map(([k, v]) => k + ' [' + v.join(', ') + ']').join('; ')).join('\n'));
  }
  const bid = +req.body.building_id || null, sid = +req.body.spot_id || null;
  const r = (await q('INSERT INTO inspections(inspector_id,building_id,spot_id,image_url,ai,condition,confidence) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *', [req.user.id, bid, sid, url(req.file), out ? JSON.stringify(out) : null, out ? out.condition : null, out ? out.confidence : null])).rows[0];
  res.status(201).json(sg(r));
}));
router.get('/', ah(async (req, res) => {
  const { limit, offset } = page(req);
  res.json((await q(`SELECT i.*,b.name building,s.name spot,u.name inspector FROM inspections i LEFT JOIN buildings b ON b.id=i.building_id LEFT JOIN spots s ON s.id=i.spot_id JOIN users u ON u.id=i.inspector_id ORDER BY i.id DESC LIMIT ${limit} OFFSET ${offset}`)).rows.map(sg));
}));
router.get('/:id', ah(async (req, res) => {
  const r = (await q('SELECT * FROM inspections WHERE id=$1', [req.params.id])).rows[0]; if (!r) throw new HttpError(404, 'Inspection not found'); res.json(sg(r));
}));
module.exports = router;
