const router = require('express').Router(), { q } = require('../db'), { auth, role } = require('../middleware/auth'), { ah } = require('../utils');
router.use(auth, role('admin'));
router.get('/export/complaints.csv', ah(async (req, res) => {
  const { rows } = await q(`SELECT c.code,c.title,c.category,c.priority,c.status,b.name building,s.name spot,u.name reporter,a.name assignee,c.lat,c.lng,c.created_at,c.resolved_at
    FROM complaints c LEFT JOIN buildings b ON b.id=c.building_id LEFT JOIN spots s ON s.id=c.spot_id JOIN users u ON u.id=c.reporter_id LEFT JOIN users a ON a.id=c.assigned_to ORDER BY c.id`);
  const cols = rows[0] ? Object.keys(rows[0]) : ['code'], esc = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  res.set({ 'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename="complaints.csv"' });
  res.send([cols.join(','), ...rows.map(r => cols.map(c => esc(r[c])).join(','))].join('\n'));
}));
router.get('/audit', ah(async (req, res) => { const { limit, offset } = require('../utils').page(req); res.json((await q(`SELECT a.*,u.name actor FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT ${limit} OFFSET ${offset}`)).rows); }));
module.exports = router;
