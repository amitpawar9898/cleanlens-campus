require('dotenv').config();
const e = process.env, prod = e.NODE_ENV === 'production';
const cfg = {
  prod, port: +e.PORT || 4000,
  dbUrl: e.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/cleanlens',
  jwtSecret: e.JWT_SECRET || 'dev-secret-change-me', accessTtl: e.ACCESS_TTL || '15m', refreshDays: +e.REFRESH_DAYS || 30,
  corsOrigin: e.CORS_ORIGIN || '*', uploadDir: e.UPLOAD_DIR || 'uploads',
  anthropicKey: e.ANTHROPIC_API_KEY || '', model: e.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
  sms: { provider: e.SMS_PROVIDER || 'console', twilioSid: e.TWILIO_SID, twilioToken: e.TWILIO_TOKEN, twilioFrom: e.TWILIO_FROM, fast2sms: e.FAST2SMS_KEY },
  seed: { email: e.SEED_ADMIN_EMAIL || '', password: e.SEED_ADMIN_PASSWORD || '' }
};
if (prod && cfg.jwtSecret === 'dev-secret-change-me') { console.error('Set JWT_SECRET in production.'); process.exit(1); }
module.exports = cfg;
