# Feature checklist (what is real, what is tested)

"Tested" means an automated test in `backend/test/` passed against a real PostgreSQL 16 database (`npm run smoke` for the API, `npm run test:ui` for all screens), or a manual headless-browser run noted below.

The complaint-to-cleaner workflow and portal updates in this package have been implemented, and the automated tests have been extended. They still need to be run against PostgreSQL: Docker Desktop and a local PostgreSQL server were unavailable in the environment used for this update. The pre-existing "Tested" entries below describe earlier project validation, not a passing run of the updated tests.

## Backend connection and demo-data removal
| Part | Status |
|---|---|
| Standalone launcher | Replaced the browser-only demo with a server URL form and `/api/health` check; opens the backend-hosted portal on success |
| Standalone browser sample records | Removed with the previous standalone app; launcher removes only its old complaint/task/map/user localStorage keys |
| New database seed | Creates configured admin and department categories only; no fixed demo accounts, buildings, spots or complaints |
| Old database demo records | Explicit cleanup is available as `npm run clean:demo -- --confirm`; review and back up the database first. Real linked records are retained |
| Admin credentials | Required via `SEED_ADMIN_EMAIL` and unique 12+ character `SEED_ADMIN_PASSWORD`; no fixed credential fallback |
| End-to-end database tests | Updated to create their own test users/locations and clean up after themselves; not run because PostgreSQL was unavailable |

## UI redesign (reference image) — scope of this pass
| Part | Status |
|---|---|
| Split-screen login (leaf logo, tagline, Report/Inspect/Clean/Maintain, Welcome Back card) | Implemented, Tested in a real browser. Non-working controls removed (Google/Microsoft buttons, Remember me, Forgot password). The campus photo shows once you add `campus.jpg` |
| Top bar with breadcrumb, notification count, user name and role | Implemented |
| Admin dashboard (8 KPI cards, trend, category, building, completion rate, recent complaints, attention list, overdue, admin activity, quick actions) | Implemented, data from the API only; empty states when there is no data |
| Cleaner portal navigation and responsive task workspace | Implemented; updated workflow tests pending |
| Supervisor dashboard (KPIs, verification queue, attention list) | Implemented, Tested |
| Student dashboard (inline report form with photo preview + recent complaints) | Implemented, Tested |
| Mobile layouts of the above | Implemented (screenshots checked) |
| Restyle of the other pages to match exactly (users table, complaints table, analytics, AI inspection drag-and-drop layout, verification screen with checklist) | **Not done**: they use the shared green styling but not the reference layouts |
| Collapsible sidebar, top-bar search, profile menu | **Not done** |
| Cleaner task checklist and task detail/evidence review | Implemented; database test pending |
| Departments page, rankings page, settings page | **Not implemented** |

## Backend and workflow checklist
| Module | Status | Notes |
|---|---|---|
| Register / login / JWT / refresh tokens / logout | Implemented, Tested | bcrypt hashes, 15-minute access tokens, rotating refresh tokens |
| Server-side role checks (admin, staff, cleaner, student) | Implemented, Tested | students cannot list users or change roles; cleaners cannot verify; audit log is admin only |
| Student complaints (photo, location, category, tracking, feedback) | Implemented; updated workflow tests pending | Requires a description and photo; new complaint IDs start in Submitted |
| Complaint status workflow | Implemented; updated workflow tests pending | Submitted → Reviewed → Assigned → In Progress → Pending Verification → Resolved; invalid transitions are rejected |
| Cleaner task workflow | Implemented; updated workflow tests pending | Assignment includes a checklist and supports before/after evidence; correction required returns the task to the cleaner |
| Supervisor verification (approve / return for correction) | Implemented; updated workflow tests pending | Staff are limited to their department; task, complaint, timeline, audit and notifications are committed together |
| Private photos (no public URLs) | Implemented, Tested | 15-minute signed links at `/files/…`; tampered links and path traversal rejected; `/uploads` no longer public |
| Audit log (user changes, complaint changes/deletes, verification decisions) | Implemented, Tested | `GET /api/admin/audit` (admin only); location and export actions are not logged yet |
| Notifications (database-backed, unread count) | Implemented; updated workflow tests pending | complaint submission/review, assignment, progress, corrections, approval, resolution, approaching deadlines and overdue tasks |
| Analytics and CSV export | Implemented, Tested | totals, by category and priority, 7-day trend, location scores, cleaner stats; **no date filters yet** |
| AI photo analysis | Implemented, Partly tested | server-side Claude vision when `ANTHROPIC_API_KEY` is set (not live-tested, no key here); on-device YOLO11 fallback tested in a real browser. Results are shown as suggestions with the method named |
| Database migrations and seed | Implemented, Tested | run twice with no duplicates |
| Web app (all screens, responsive, phone install) | Implemented, Tested | screens tested with jsdom and real Chromium |
| Docker / Docker Compose | Implemented, **Not tested** | Docker was not available in the build environment |
| Task deadlines and overdue notifications | Implemented; updated workflow tests pending | Cleaner gets a reminder within 24 hours; admins get overdue notices while the API server is running |
| Admin: total users, cleaners/supervisors counts, tasks counts on the dashboard | **Partly** | complaint and task totals are real; user counts and overdue are not shown |
| Location management with types (classroom, lab, washroom…) and active flag | **Not implemented** | buildings and spots can be added/removed; no type, edit or deactivate |
| Department management screen and area assignment | **Not implemented** | departments exist in the database and drive routing |
| Inspections with checklists, scores, history and cleanest/least-clean ranking | **Not implemented** | only AI photo inspections are saved; the map score is a simple penalty formula from open complaints |
| Configurable scoring service with stored factors and version | **Not implemented** | fixed weights in `src/services/scoring.js` |
| Cleaner checklist and required before/after photos | Implemented; updated workflow tests pending | Five checklist items must be complete before submission |
| Separate Supervisor dashboard | **Not implemented** | supervisors use the shared app with department-limited data |
| Reporter follow-up comments | Implemented (API), **Not tested** in UI | |
| Human correction of AI results saved to the database | **Not implemented** | confirm/reject buttons exist but are not stored |
| Reports with date filters | **Not implemented** | |
| Rate limiting on every sensitive endpoint, database-failure tests | Partly / **Not tested** | auth and AI endpoints are rate limited |

Remaining work is mostly the Not implemented rows above. Tell me which module to build next.
