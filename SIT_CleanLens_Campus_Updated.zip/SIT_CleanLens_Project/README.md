# SIT CleanLens Campus — Project package

Smart campus cleanliness and complaint platform for Symbiosis Institute of Technology, Pune.
Report a problem with a photo → AI detects the issue and fills the form → admin reviews and assigns a cleaner → cleaner completes the checklist and uploads before/after photos → admin verifies the work → student is notified.

## What is inside
| Folder | What it is | When to use it |
|---|---|---|
| `standalone/SIT_CleanLens.html` | A lightweight launcher that connects to the live backend and opens its portal. It contains no complaint or account dataset. | Launch the backend-connected app from a file or static host. |
| `backend/` | The real system: Node.js + Express + PostgreSQL API, the same web app wired to it, phone-install support (PWA), Docker files, tests, full API docs. | Real use with shared data for many students, cleaners and admins. |

## Run the backend-connected system
```
cd backend
npm install
Copy-Item .env.example .env  # PowerShell; set PostgreSQL URL, JWT_SECRET and your admin credentials
npm run migrate
npm run seed                 # adds departments and one configured admin; no sample complaints/users/locations
npm start                    # open http://localhost:4000
```
Set `SEED_ADMIN_EMAIL` and a unique `SEED_ADMIN_PASSWORD` (at least 12 characters) in `.env` before seeding. Students register from the portal; an admin creates staff and cleaner accounts and adds the actual campus buildings and locations under Admin → Locations. No fixed demo passwords or sample complaints are created.

To use Docker, start Docker Desktop and run `docker compose up --build`, then seed the database with `docker compose exec api node db/seed.js`. The standalone launcher asks for a backend address (by default `http://localhost:4000`) and opens that server's live portal.

Tests: `npm run smoke` and `npm run test:ui` (requires a running, migrated PostgreSQL backend and a configured admin account). To remove the legacy sample complaints and unused old demo accounts from an existing database, back it up and explicitly run `npm run clean:demo -- --confirm`. Full setup and API reference: `backend/README.md`.
For real photo analysis put `ANTHROPIC_API_KEY` in `.env`. Without it the app uses the on-device YOLO11 model.

The backend complaint workflow starts at **Submitted**. An admin or department staff member reviews each report before assigning a cleaner, instructions and an optional deadline. Cleaners complete the persisted checklist and upload both before- and after-cleaning photos; only an authorized reviewer can verify the work or return it for correction. Notifications and task/complaint history are stored in PostgreSQL. Run the updated API and UI tests against a running, migrated and seeded database.

## Phone app
Host the backend over HTTPS. Android Chrome then offers **Install app**; on iPhone use Safari → Share → Add to Home Screen. A native Android/iOS wrapper is in `backend/mobile/` (see its README). Camera and GPS need HTTPS.

## Honest status
See `STATUS.md` for the module-by-module checklist (Implemented / Tested / Not implemented).

- The standalone launcher is not a data demo; the PostgreSQL-backed app is the source of truth for accounts, reports and tasks.
- Done: role-specific navigation, photo detection (stock YOLO11), complaint details with timeline, transactional complaint/task verification workflow, required task checklist and photos, admin tools, API, phone install and workflow test coverage.
- Not done: deployment and HTTPS, real SMS/email accounts, Google/Microsoft sign-in, a YOLO model trained on waste photos (stock model only knows 80 everyday objects and can miss waste), email/push notifications, and the later phases (prediction, rankings, hygiene risk).
- On the backend, photos are private: the API returns 15-minute signed links.
